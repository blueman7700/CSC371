/*
  +---------------------------------------+
  | BETH YW? WELSH GOVERNMENT DATA PARSER |
  +---------------------------------------+

  AUTHOR: Dr Martin Porcheron

  You must not modify this file as it will be replaced with a fresh copy
  during marking.
 */

#include "bethyw.h"

int main(int argc, char *argv[]) {

	return BethYw::run(argc, argv);
}